export enum ThemeList {
  System = 'system',
  Light = 'light',
  Dark = 'dark',
}

export const DEFAULT_BASE_THEME = ThemeList.System;
