interface IMessage {
  sender: string;
  receiver: string;
  content: string;
}
