interface INotification {
  type: string;
  title: string;
  message: string;
  override?: any;
  context?: any;
}
