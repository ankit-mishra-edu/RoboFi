import { Component } from '@angular/core';

@Component({
  templateUrl: './billing.page.html',
  styleUrls: ['./billing.page.scss'],
})
export class BillingPage {}
