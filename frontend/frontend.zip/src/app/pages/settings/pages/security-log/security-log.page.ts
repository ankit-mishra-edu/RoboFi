import { Component } from '@angular/core';

@Component({
  templateUrl: './security-log.page.html',
  styleUrls: ['./security-log.page.scss'],
})
export class SecurityLogPage {}
