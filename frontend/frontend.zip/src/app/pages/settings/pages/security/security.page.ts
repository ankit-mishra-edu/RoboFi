import { Component } from '@angular/core';

@Component({
  templateUrl: './security.page.html',
  styleUrls: ['./security.page.scss'],
})
export class SecurityPage {}
