import { Workflow } from './workflow';

describe('Workflow', () => {
  it('should create an instance', () => {
    expect(new Workflow()).toBeTruthy();
  });
});
