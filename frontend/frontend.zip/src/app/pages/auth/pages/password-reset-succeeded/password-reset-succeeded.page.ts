import { Component } from '@angular/core';

@Component({
  templateUrl: './password-reset-succeeded.page.html',
  styleUrls: ['./password-reset-succeeded.page.scss'],
})
export class PasswordResetSucceededPage {}
