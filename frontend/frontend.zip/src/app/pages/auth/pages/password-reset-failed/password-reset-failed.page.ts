import { Component } from '@angular/core';

@Component({
  templateUrl: './password-reset-failed.page.html',
  styleUrls: ['./password-reset-failed.page.scss'],
})
export class PasswordResetFailedPage {}
