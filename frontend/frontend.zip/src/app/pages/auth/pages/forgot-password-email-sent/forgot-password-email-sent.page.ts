import { Component } from '@angular/core';

@Component({
  templateUrl: './forgot-password-email-sent.page.html',
  styleUrls: ['./forgot-password-email-sent.page.scss'],
})
export class ForgotPasswordEmailSentPage {}
