export const environment = {
  production: true,
  API_BASE_URL: 'https://robofi.herokuapp.com/api',
  MEDIA_BASE_URL: 'https://res.cloudinary.com/hnose3kua/',
};
